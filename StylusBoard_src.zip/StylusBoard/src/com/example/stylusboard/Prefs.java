package com.example.stylusboard;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 触控笔按键自定义配置。
 * 小猿AI学习机把"笔身按键 -> 橡皮/圈选"写死在 com.megrez.x1.view.util.e.a() 中，
 * 本类把该映射开放为可配置项。
 */
public final class Prefs {

    private static final String FILE = "stylus_board";

    private static final String KEY_STYLUS_ONLY = "stylus_only";
    private static final String KEY_KEY_ACTION = "key_action";
    private static final String KEY_KEY_BUTTON = "key_button";
    private static final String KEY_DEBUG_OVERLAY = "debug_overlay";
    private static final String KEY_PEN_WIDTH = "pen_width";
    private static final String KEY_LASSO_RATIO = "lasso_ratio";

    /** 关闭：手指也能画。开启：完全复刻 StylusLayout，只放行 toolType 2/4 */
    public static final boolean DEFAULT_STYLUS_ONLY = false;
    /** 笔身按键默认行为 = 圈选删除 */
    public static final int DEFAULT_KEY_ACTION = StylusBoardView.MODE_LASSO;
    /** 默认监听笔身主键 0x20，与小猿 buttonState==32 判定一致 */
    public static final int DEFAULT_KEY_BUTTON = StylusUtil.BTN_STYLUS_PRIMARY;
    public static final boolean DEFAULT_DEBUG_OVERLAY = true;
    public static final float DEFAULT_PEN_WIDTH = 7f;
    /** 笔迹被判定"圈中"所需的落点比例 */
    public static final float DEFAULT_LASSO_RATIO = 0.5f;

    private final SharedPreferences sp;

    public Prefs(Context context) {
        this.sp = context.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public boolean isStylusOnly() {
        return sp.getBoolean(KEY_STYLUS_ONLY, DEFAULT_STYLUS_ONLY);
    }

    public void setStylusOnly(boolean v) {
        sp.edit().putBoolean(KEY_STYLUS_ONLY, v).apply();
    }

    public int getKeyAction() {
        return sp.getInt(KEY_KEY_ACTION, DEFAULT_KEY_ACTION);
    }

    public void setKeyAction(int v) {
        sp.edit().putInt(KEY_KEY_ACTION, v).apply();
    }

    public int getKeyButton() {
        return sp.getInt(KEY_KEY_BUTTON, DEFAULT_KEY_BUTTON);
    }

    public void setKeyButton(int v) {
        sp.edit().putInt(KEY_KEY_BUTTON, v).apply();
    }

    public boolean isDebugOverlay() {
        return sp.getBoolean(KEY_DEBUG_OVERLAY, DEFAULT_DEBUG_OVERLAY);
    }

    public void setDebugOverlay(boolean v) {
        sp.edit().putBoolean(KEY_DEBUG_OVERLAY, v).apply();
    }

    public float getPenWidth() {
        return sp.getFloat(KEY_PEN_WIDTH, DEFAULT_PEN_WIDTH);
    }

    public void setPenWidth(float v) {
        sp.edit().putFloat(KEY_PEN_WIDTH, v).apply();
    }

    public float getLassoRatio() {
        return sp.getFloat(KEY_LASSO_RATIO, DEFAULT_LASSO_RATIO);
    }

    public void setLassoRatio(float v) {
        sp.edit().putFloat(KEY_LASSO_RATIO, v).apply();
    }
}
