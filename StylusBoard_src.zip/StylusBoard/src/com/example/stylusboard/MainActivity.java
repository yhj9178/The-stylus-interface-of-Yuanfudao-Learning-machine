package com.example.stylusboard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

/**
 * 主界面：触控笔画板 + 工具栏。
 * 纯 framework API（手工打包，无 androidx）。
 */
public class MainActivity extends Activity implements StylusBoardView.OnStylusStateListener {

    private StylusBoardView board;
    private TextView statusText;
    private Button modePen, modeEraser, modeLasso;
    private final Button[] colorButtons = new Button[5];

    private Prefs prefs;

    private static final int[] PEN_COLORS = new int[]{
            0xFF1B5EF4, 0xFF111111, 0xFFE53935, 0xFF43A047, 0xFFFB8C00
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF2F3F5);

        statusText = new TextView(this);
        statusText.setTextSize(13f);
        statusText.setTextColor(0xFF37474F);
        statusText.setTypeface(Typeface.MONOSPACE);
        int pad = dp(12);
        statusText.setPadding(pad, pad, pad, pad);
        statusText.setText(buildHint());
        root.addView(statusText, matchWidth());

        board = new StylusBoardView(this);
        board.setOnStylusStateListener(this);
        LinearLayout.LayoutParams boardLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        boardLp.setMargins(pad, 0, pad, pad);
        root.addView(board, boardLp);

        root.addView(buildModeRow(), matchWidth());
        root.addView(buildColorRow(), matchWidth());
        root.addView(buildActionRow(), matchWidth());

        // 画板必须占据剩余空间：不能放进 ScrollView，否则 weight=1 的高度会塌缩为 0，
        // 导致触摸区域消失（无法书写）且 getWidth()/getHeight() 返回 0（"画板尚未就绪"）。
        setContentView(root);

        board.applyPrefs(prefs);
        applyModeHighlight();
        applyColorHighlight();
    }

    @Override
    protected void onResume() {
        super.onResume();
        board.applyPrefs(prefs);
        applyModeHighlight();
        applyColorHighlight();
    }

    private LinearLayout.LayoutParams matchWidth() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout buildModeRow() {
        LinearLayout row = newRow();
        modePen = makeButton("画笔", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                board.setActiveMode(StylusBoardView.MODE_PEN);
                applyModeHighlight();
            }
        });
        modeEraser = makeButton("橡皮", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                board.setActiveMode(StylusBoardView.MODE_ERASER);
                applyModeHighlight();
            }
        });
        modeLasso = makeButton("圈选删除", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                board.setActiveMode(StylusBoardView.MODE_LASSO);
                applyModeHighlight();
            }
        });
        row.addView(modePen, weightItem());
        row.addView(modeEraser, weightItem());
        row.addView(modeLasso, weightItem());
        return row;
    }

    private LinearLayout buildColorRow() {
        LinearLayout row = newRow();
        for (int i = 0; i < PEN_COLORS.length; i++) {
            final int idx = i;
            Button b = new Button(this);
            b.setText("●");
            b.setTextColor(PEN_COLORS[i]);
            b.setTextSize(18f);
            b.setAllCaps(false);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    board.setPenColor(PEN_COLORS[idx]);
                    applyColorHighlight();
                    applyModeHighlight();
                }
            });
            colorButtons[i] = b;
            row.addView(b, weightItem());
        }
        return row;
    }

    private LinearLayout buildActionRow() {
        LinearLayout row = newRow();
        row.addView(makeButton("撤销", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                board.undo();
            }
        }), weightItem());
        row.addView(makeButton("重做", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                board.redo();
            }
        }), weightItem());
        row.addView(makeButton("清空", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                board.clearAll();
            }
        }), weightItem());
        row.addView(makeButton("保存PNG", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exportPng();
            }
        }), weightItem());
        row.addView(makeButton("设置", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        }), weightItem());
        return row;
    }

    private LinearLayout newRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int pad = dp(12);
        row.setPadding(pad, dp(2), pad, dp(2));
        return row;
    }

    private LinearLayout.LayoutParams weightItem() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private Button makeButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14f);
        b.setOnClickListener(listener);
        return b;
    }

    private void applyModeHighlight() {
        int m = board.getActiveMode();
        highlight(modePen, m == StylusBoardView.MODE_PEN);
        highlight(modeEraser, m == StylusBoardView.MODE_ERASER);
        highlight(modeLasso, m == StylusBoardView.MODE_LASSO);
    }

    private void applyColorHighlight() {
        int cur = board.getPenColor();
        for (int i = 0; i < colorButtons.length; i++) {
            highlight(colorButtons[i], cur == PEN_COLORS[i]
                    && board.getActiveMode() == StylusBoardView.MODE_PEN);
        }
    }

    private void highlight(Button b, boolean on) {
        b.setBackgroundColor(on ? 0xFF1B5EF4 : Color.WHITE);
        b.setTextColor(on ? Color.WHITE : 0xFF222222);
    }

    private String buildHint() {
        return "触控笔画板 · 按住笔身按键可触发【"
                + StylusBoardView.modeName(prefs.getKeyAction())
                + "】\n进入【设置】可自定义按键行为与是否仅笔可写。手指也可书写(默认)。";
    }

    @Override
    public void onStylusState(int toolType, int buttonState, int activeMode, int strokeCount) {
        String s = "toolType=" + toolType + " (" + StylusUtil.toolName(toolType) + ")"
                + "   buttonState=" + StylusUtil.buttonName(buttonState)
                + "   当前=" + StylusBoardView.modeName(activeMode)
                + "   笔迹=" + strokeCount;
        if (statusText != null) {
            statusText.setText(s);
        }
    }

    private void exportPng() {
        int w = board.getWidth(), h = board.getHeight();
        if (w <= 0 || h <= 0) {
            Toast.makeText(this, "画板尚未就绪", Toast.LENGTH_SHORT).show();
            return;
        }
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        board.exportTo(c);
        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (dir == null) {
            dir = getFilesDir();
        }
        File out = new File(dir, "board_" + System.currentTimeMillis() + ".png");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(out);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            Toast.makeText(this, "已保存: " + out.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "保存失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (Exception ignored) {
                }
            }
            bmp.recycle();
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
