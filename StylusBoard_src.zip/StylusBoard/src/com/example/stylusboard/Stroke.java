package com.example.stylusboard;

import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

/**
 * 一条笔迹：采样点 + 逐点宽度 + 平滑路径 + 包围盒。
 * 对应小猿AI学习机 HandwritingPath / HandwritePoint 的最小可复刻模型。
 */
public class Stroke {

    public final List<PointF> points = new ArrayList<PointF>(64);
    public final List<Float> widths = new ArrayList<Float>(64);
    public final Path path = new Path();
    public final RectF bounds = new RectF();

    public int color;
    public int alpha = 255;
    public boolean highlighter;

    private float widthSum;
    private boolean boundsValid;

    public void start(float x, float y, float w) {
        points.clear();
        widths.clear();
        path.reset();
        widthSum = 0f;
        boundsValid = false;
        append(x, y, w);
        path.moveTo(x, y);
    }

    /** 二次贝塞尔中点平滑，与小猿手写路径的观感一致 */
    public void extend(float x, float y, float w) {
        int n = points.size();
        if (n == 0) {
            start(x, y, w);
            return;
        }
        PointF prev = points.get(n - 1);
        path.quadTo(prev.x, prev.y, (prev.x + x) * 0.5f, (prev.y + y) * 0.5f);
        append(x, y, w);
    }

    public void seal() {
        int n = points.size();
        if (n >= 2) {
            PointF last = points.get(n - 1);
            path.lineTo(last.x, last.y);
        }
    }

    private void append(float x, float y, float w) {
        points.add(new PointF(x, y));
        widths.add(w);
        widthSum += w;
        float r = w * 0.5f + 1f;
        if (!boundsValid) {
            bounds.set(x - r, y - r, x + r, y + r);
            boundsValid = true;
        } else {
            if (x - r < bounds.left) bounds.left = x - r;
            if (y - r < bounds.top) bounds.top = y - r;
            if (x + r > bounds.right) bounds.right = x + r;
            if (y + r > bounds.bottom) bounds.bottom = y + r;
        }
    }

    public int size() {
        return points.size();
    }

    public boolean isEmpty() {
        return points.isEmpty();
    }

    public PointF pointAt(int i) {
        return points.get(i);
    }

    public float widthAt(int i) {
        return i < widths.size() ? widths.get(i) : 1f;
    }

    public float avgWidth() {
        return widths.isEmpty() ? 1f : widthSum / widths.size();
    }

    public PointF centroid() {
        int n = points.size();
        if (n == 0) {
            return new PointF();
        }
        float sx = 0f, sy = 0f;
        for (int i = 0; i < n; i++) {
            sx += points.get(i).x;
            sy += points.get(i).y;
        }
        return new PointF(sx / n, sy / n);
    }

    /** 等间隔降采样，供圈选包含判定使用 */
    public List<PointF> sample(int maxSamples) {
        int n = points.size();
        if (n <= maxSamples || maxSamples < 2) {
            return points;
        }
        ArrayList<PointF> out = new ArrayList<PointF>(maxSamples);
        float step = (n - 1) / (float) (maxSamples - 1);
        for (int i = 0; i < maxSamples; i++) {
            out.add(points.get(Math.round(i * step)));
        }
        return out;
    }

    public boolean hasPointNear(float x, float y, float r) {
        float r2 = r * r;
        for (int i = 0, n = points.size(); i < n; i++) {
            PointF p = points.get(i);
            float dx = p.x - x, dy = p.y - y;
            if (dx * dx + dy * dy <= r2) {
                return true;
            }
        }
        return false;
    }
}
