package com.example.stylusboard;

import android.view.MotionEvent;

/**
 * 触控笔识别工具类。
 *
 * 复刻自 小猿AI学习机(com.megrez.app.x1.business) classes4.dex 中的
 * com.megrez.x1.view.util.e#a(android.view.MotionEvent)：
 *
 *   public static final int a(MotionEvent event) {
 *       if (event.getButtonState() == 32) return 4;
 *       return event.getToolType(0);
 *   }
 *
 * 语义：笔身按键(buttonState==0x20)被按下时，把"有效工具类型"改写为 4，
 * 上层 StylusLayout 据此进入橡皮/圈选态；否则使用系统上报的真实工具类型。
 */
public final class StylusUtil {

    private StylusUtil() {
    }

    public static final int TOOL_UNKNOWN = 0;
    public static final int TOOL_FINGER = 1;
    public static final int TOOL_STYLUS = 2;
    public static final int TOOL_MOUSE = 3;
    /**
     * 值 4：Android 8 及以前为 TOOL_TYPE_BRUSH，Android 13(API 33) 起系统定义为 TOOL_TYPE_ERASER。
     * 小猿借用该值表示"笔身按键按下 -> 橡皮/圈选态"。
     */
    public static final int TOOL_BRUSH_OR_ERASER = 4;

    /** MotionEvent.BUTTON_STYLUS_PRIMARY = 0x20 (32)，即小猿判定所用的笔身主按键 */
    public static final int BTN_STYLUS_PRIMARY = 0x20;
    /** MotionEvent.BUTTON_STYLUS_SECONDARY = 0x40 (64) */
    public static final int BTN_STYLUS_SECONDARY = 0x40;
    /** 两个笔身按键任意一个 */
    public static final int BTN_STYLUS_ANY = BTN_STYLUS_PRIMARY | BTN_STYLUS_SECONDARY;

    /** 与原始实现逐字节一致（严格 == 32） */
    public static int effectiveToolType(MotionEvent event) {
        if (event == null) {
            return TOOL_UNKNOWN;
        }
        if (event.getButtonState() == 32) {
            return TOOL_BRUSH_OR_ERASER;
        }
        return event.getToolType(0);
    }

    /** 增强版：按键位掩码可由用户自定义，指针索引取当前动作指针 */
    public static int effectiveToolType(MotionEvent event, int buttonMask) {
        if (event == null) {
            return TOOL_UNKNOWN;
        }
        if (isKeyDown(event, buttonMask)) {
            return TOOL_BRUSH_OR_ERASER;
        }
        int index = event.getActionIndex();
        return index < event.getPointerCount() ? event.getToolType(index) : event.getToolType(0);
    }

    public static boolean isKeyDown(MotionEvent event, int buttonMask) {
        if (event == null) {
            return false;
        }
        int state = event.getButtonState();
        if (buttonMask == BTN_STYLUS_ANY) {
            return (state & BTN_STYLUS_ANY) != 0;
        }
        return buttonMask != 0 && (state & buttonMask) != 0;
    }

    public static boolean isStylusTool(int toolType) {
        return toolType == TOOL_STYLUS || toolType == TOOL_BRUSH_OR_ERASER;
    }

    public static String toolName(int toolType) {
        switch (toolType) {
            case TOOL_FINGER:
                return "FINGER(手指)";
            case TOOL_STYLUS:
                return "STYLUS(触控笔)";
            case TOOL_MOUSE:
                return "MOUSE(鼠标)";
            case TOOL_BRUSH_OR_ERASER:
                return "BRUSH/ERASER(笔键态)";
            default:
                return "UNKNOWN(未知)";
        }
    }

    public static String buttonName(int buttonState) {
        if (buttonState == 0) {
            return "0x00 无按键";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("0x").append(Integer.toHexString(buttonState).toUpperCase());
        if ((buttonState & BTN_STYLUS_PRIMARY) != 0) {
            sb.append(" 笔身主键(0x20)");
        }
        if ((buttonState & BTN_STYLUS_SECONDARY) != 0) {
            sb.append(" 笔身副键(0x40)");
        }
        if ((buttonState & 0x01) != 0) {
            sb.append(" BTN_PRIMARY");
        }
        return sb.toString();
    }
}
