
package com.example.stylusboard;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 触控笔按键自定义设置页。
 * 纯 framework API（手工打包，无 androidx / PreferenceFragment）。
 */
public class SettingsActivity extends Activity {

    private Prefs prefs;

    private CheckBox stylusOnlyCheck, debugCheck;
    private RadioGroup keyActionGroup, keyButtonGroup;
    private SeekBar lassoRatioBar, penWidthBar;
    private TextView lassoRatioValue, penWidthValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);

        root.addView(sectionTitle("触控笔识别（复刻小猿 StylusLayout）"));

        stylusOnlyCheck = new CheckBox(this);
        stylusOnlyCheck.setText("仅触控笔可书写（手指事件被丢弃）");
        stylusOnlyCheck.setTextSize(15f);
        stylusOnlyCheck.setChecked(prefs.isStylusOnly());
        stylusOnlyCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                prefs.setStylusOnly(isChecked);
            }
        });
        root.addView(stylusOnlyCheck, matchWidth());

        root.addView(hint("对应原逻辑：onFilterTouchEventForSecurity 中\n"
                + "effectiveToolType(e)==2(STYLUS) 或 ==4(笔键态/BRUSH) 才放行"));

        root.addView(sectionTitle("笔身按键自定义（复刻 e.a() 的 buttonState==32）"));

        keyActionGroup = new RadioGroup(this);
        keyActionGroup.addView(radio("按键时进入【圈选删除】", StylusBoardView.MODE_LASSO,
                prefs.getKeyAction()));
        keyActionGroup.addView(radio("按键时进入【橡皮擦】", StylusBoardView.MODE_ERASER,
                prefs.getKeyAction()));
        keyActionGroup.addView(radio("按键时进入【画笔】", StylusBoardView.MODE_PEN,
                prefs.getKeyAction()));
        keyActionGroup.addView(radio("按键时执行【撤销】", StylusBoardView.MODE_UNDO,
                prefs.getKeyAction()));
        keyActionGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                View child = group.findViewById(checkedId);
                if (child != null && child.getTag() instanceof Integer) {
                    prefs.setKeyAction(((Integer) child.getTag()).intValue());
                }
            }
        });
        root.addView(keyActionGroup, matchWidth());

        keyButtonGroup = new RadioGroup(this);
        keyButtonGroup.addView(radio("监听笔身主键 0x20（与小猿一致）",
                StylusUtil.BTN_STYLUS_PRIMARY, prefs.getKeyButton()));
        keyButtonGroup.addView(radio("监听笔身副键 0x40",
                StylusUtil.BTN_STYLUS_SECONDARY, prefs.getKeyButton()));
        keyButtonGroup.addView(radio("监听任意笔身按键 0x60",
                StylusUtil.BTN_STYLUS_ANY, prefs.getKeyButton()));
        keyButtonGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                View child = group.findViewById(checkedId);
                if (child != null && child.getTag() instanceof Integer) {
                    prefs.setKeyButton(((Integer) child.getTag()).intValue());
                }
            }
        });
        root.addView(keyButtonGroup, matchWidth());

        root.addView(sectionTitle("圈选与笔参数"));

        root.addView(label("圈选包含阈值（笔迹落入圈内的采样点比例）"));
        lassoRatioBar = new SeekBar(this);
        lassoRatioBar.setMax(95);
        lassoRatioBar.setProgress(Math.round((prefs.getLassoRatio() - 0.05f) * 100f));
        lassoRatioValue = new TextView(this);
        lassoRatioValue.setTextSize(13f);
        lassoRatioValue.setText(fmtRatio(prefs.getLassoRatio()));
        lassoRatioBar.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float v = 0.05f + progress / 100f;
                prefs.setLassoRatio(v);
                lassoRatioValue.setText(fmtRatio(v));
            }
        });
        root.addView(lassoRatioBar, matchWidth());
        root.addView(lassoRatioValue, matchWidth());

        root.addView(label("笔迹粗细 (dp)"));
        penWidthBar = new SeekBar(this);
        penWidthBar.setMax(28);
        penWidthBar.setProgress(Math.round(prefs.getPenWidth() - 2f));
        penWidthValue = new TextView(this);
        penWidthValue.setTextSize(13f);
        penWidthValue.setText(fmtWidth(prefs.getPenWidth()));
        penWidthBar.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float v = 2f + progress;
                prefs.setPenWidth(v);
                penWidthValue.setText(fmtWidth(v));
            }
        });
        root.addView(penWidthBar, matchWidth());
        root.addView(penWidthValue, matchWidth());

        debugCheck = new CheckBox(this);
        debugCheck.setText("画板左上角显示 toolType / buttonState 调试信息");
        debugCheck.setTextSize(15f);
        debugCheck.setChecked(prefs.isDebugOverlay());
        debugCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                prefs.setDebugOverlay(isChecked);
            }
        });
        root.addView(debugCheck, matchWidth());

        Button reset = new Button(this);
        reset.setText("恢复小猿默认值");
        reset.setAllCaps(false);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.setStylusOnly(Prefs.DEFAULT_STYLUS_ONLY);
                prefs.setKeyAction(Prefs.DEFAULT_KEY_ACTION);
                prefs.setKeyButton(Prefs.DEFAULT_KEY_BUTTON);
                prefs.setDebugOverlay(Prefs.DEFAULT_DEBUG_OVERLAY);
                prefs.setPenWidth(Prefs.DEFAULT_PEN_WIDTH);
                prefs.setLassoRatio(Prefs.DEFAULT_LASSO_RATIO);
                reload();
            }
        });
        root.addView(reset, wrapHeight());

        root.addView(hint("提示：小猿AI学习机把该映射写死在\n"
                + "com.megrez.x1.view.util.e.a(MotionEvent) 中，\n"
                + "本页把它开放为可配置项，便于适配不同笔按键定义。"));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root, matchWidth());
        setContentView(scroll);
    }

    /** SeekBar 只关心进度变化的简化监听器 */
    private abstract static class SimpleSeekListener implements SeekBar.OnSeekBarChangeListener {
        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
        }
    }

    private void reload() {
        stylusOnlyCheck.setChecked(prefs.isStylusOnly());
        debugCheck.setChecked(prefs.isDebugOverlay());
        checkByTag(keyActionGroup, prefs.getKeyAction());
        checkByTag(keyButtonGroup, prefs.getKeyButton());
        lassoRatioBar.setProgress(Math.round((prefs.getLassoRatio() - 0.05f) * 100f));
        lassoRatioValue.setText(fmtRatio(prefs.getLassoRatio()));
        penWidthBar.setProgress(Math.round(prefs.getPenWidth() - 2f));
        penWidthValue.setText(fmtWidth(prefs.getPenWidth()));
    }

    private void checkByTag(RadioGroup group, int tag) {
        for (int i = 0, n = group.getChildCount(); i < n; i++) {
            View child = group.getChildAt(i);
            if (child instanceof RadioButton && child.getTag() instanceof Integer
                    && ((Integer) child.getTag()).intValue() == tag) {
                group.check(child.getId());
                return;
            }
        }
    }

    private RadioButton radio(String text, int value, int current) {
        RadioButton rb = new RadioButton(this);
        rb.setText(text);
        rb.setTextSize(15f);
        rb.setTag(Integer.valueOf(value));
        rb.setChecked(value == current);
        return rb;
    }

    private TextView sectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(17f);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextColor(0xFF1B5EF4);
        tv.setPadding(0, dp(18), 0, dp(6));
        return tv;
    }

    private TextView label(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14f);
        tv.setTextColor(0xFF333333);
        tv.setPadding(0, dp(12), 0, dp(2));
        return tv;
    }

    private TextView hint(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12f);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextColor(0xFF78909C);
        tv.setPadding(0, dp(4), 0, dp(4));
        return tv;
    }

    private String fmtRatio(float v) {
        return String.format(java.util.Locale.US, "当前阈值: %.2f", v);
    }

    private String fmtWidth(float v) {
        return String.format(java.util.Locale.US, "当前粗细: %.0f dp", v);
    }

    private LinearLayout.LayoutParams matchWidth() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams wrapHeight() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
