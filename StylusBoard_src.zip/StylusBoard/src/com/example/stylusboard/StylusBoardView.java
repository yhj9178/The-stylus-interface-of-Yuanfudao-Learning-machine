package com.example.stylusboard;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * 触控笔画板。
 *
 * 复刻 小猿AI学习机 三层链路：
 *  1) 识别层  com.megrez.x1.view.util.e#a(MotionEvent)  -> StylusUtil.effectiveToolType
 *  2) 分发层  com.fenbi.megrez.app.megrezView.StylusLayout#onFilterTouchEventForSecurity
 *             仅放行 toolType 2/4，手指事件被丢弃
 *  3) 应用层  按住笔身按键画闭合圈 -> 判定圈内笔迹 -> 删除
 *             原实现使用 OpenCV pointPolygonTest/convexHull，此处用等价的射线法实现。
 */
public class StylusBoardView extends View {

    public static final int MODE_PEN = 0;
    public static final int MODE_ERASER = 1;
    public static final int MODE_LASSO = 2;
    public static final int MODE_UNDO = 3;

    public static String modeName(int mode) {
        switch (mode) {
            case MODE_ERASER:
                return "橡皮擦";
            case MODE_LASSO:
                return "圈选删除";
            case MODE_UNDO:
                return "撤销";
            case MODE_PEN:
            default:
                return "画笔";
        }
    }

    /** 状态回调，供 Activity 更新顶部提示条 */
    public interface OnStylusStateListener {
        void onStylusState(int toolType, int buttonState, int activeMode, int strokeCount);
    }

    private static final int LASSO_SAMPLE = 256;
    private static final float MIN_LASSO_AREA_DP = 48f;

    private final List<Stroke> strokes = new ArrayList<Stroke>();
    private final List<Stroke> undoStack = new ArrayList<Stroke>();

    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lassoPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lassoFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hitPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint debugPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint debugBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path lassoPath = new Path();
    private final Path lassoClosed = new Path();
    private final RectF lassoBox = new RectF();

    private Bitmap layer;
    private Canvas layerCanvas;

    private Stroke current;
    private final List<PointF> lassoPoints = new ArrayList<PointF>(LASSO_SAMPLE);
    private final List<Stroke> lassoHits = new ArrayList<Stroke>(16);
    private boolean lassoActive;

    private int penColor = 0xFF1B5EF4;
    private float penWidth = 7f;
    private int activeMode = MODE_PEN;

    private boolean stylusOnly = Prefs.DEFAULT_STYLUS_ONLY;
    private int keyButton = Prefs.DEFAULT_KEY_BUTTON;
    private int keyAction = Prefs.DEFAULT_KEY_ACTION;
    private boolean debugOverlay = true;
    private float lassoRatio = Prefs.DEFAULT_LASSO_RATIO;

    private int lastToolType = StylusUtil.TOOL_UNKNOWN;
    private int lastButtonState;
    private boolean lastKeyDown;
    private int lastReportedMode = MODE_PEN;

    private OnStylusStateListener stateListener;

    public StylusBoardView(Context context) {
        this(context, null);
    }

    public StylusBoardView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public StylusBoardView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setClickable(false);
        setLongClickable(false);
        setBackgroundColor(Color.WHITE);

        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeCap(Paint.Cap.ROUND);
        strokePaint.setStrokeJoin(Paint.Join.ROUND);

        lassoPaint.setStyle(Paint.Style.STROKE);
        lassoPaint.setStrokeWidth(dp(2f));
        lassoPaint.setColor(0xFFE53935);
        lassoPaint.setPathEffect(new DashPathEffect(new float[]{dp(8f), dp(5f)}, 0f));

        lassoFillPaint.setStyle(Paint.Style.FILL);
        lassoFillPaint.setColor(0x22E53935);

        hitPaint.setStyle(Paint.Style.STROKE);
        hitPaint.setStrokeCap(Paint.Cap.ROUND);
        hitPaint.setStrokeJoin(Paint.Join.ROUND);
        hitPaint.setColor(0x66E53935);

        debugPaint.setColor(0xFF37474F);
        debugPaint.setTextSize(sp(12f));
        debugBgPaint.setColor(0xCCFFFFFF);

        lastReportedMode = activeMode;
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private float sp(float v) {
        return v * getResources().getDisplayMetrics().scaledDensity;
    }

    // ===================== 第2层：事件安全过滤（复刻 StylusLayout） =====================

    @Override
    public boolean onFilterTouchEventForSecurity(MotionEvent event) {
        if (!super.onFilterTouchEventForSecurity(event)) {
            return false;
        }
        if (!stylusOnly) {
            return true;
        }
        // 原实现：return super.onFilterTouchEventForSecurity(e) && (e.a(e) == 2 || e.a(e) == 4);
        int t = StylusUtil.effectiveToolType(event, keyButton);
        return t == StylusUtil.TOOL_STYLUS || t == StylusUtil.TOOL_BRUSH_OR_ERASER;
    }

    // ===================== 第3层：绘制 / 圈选删除 =====================

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        final int action = event.getActionMasked();
        final int pointerIndex = event.getActionIndex();
        final float x = event.getX(pointerIndex);
        final float y = event.getY(pointerIndex);

        lastButtonState = event.getButtonState();
        lastToolType = StylusUtil.effectiveToolType(event, keyButton);
        boolean keyDown = StylusUtil.isKeyDown(event, keyButton);
        lastKeyDown = keyDown;
        int mode = keyDown ? keyAction : activeMode;

        if (action == MotionEvent.ACTION_BUTTON_PRESS
                || action == MotionEvent.ACTION_BUTTON_RELEASE) {
            notifyState(mode);
            invalidate();
            return true;
        }

        float w = widthFromPressure(event.getPressure(pointerIndex), event.getSize(pointerIndex));

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                if (mode == MODE_UNDO) {
                    undo();
                } else if (mode == MODE_LASSO) {
                    beginLasso(x, y);
                } else if (mode == MODE_ERASER) {
                    eraseAt(x, y, w);
                } else {
                    beginStroke(x, y, w);
                }
                break;

            case MotionEvent.ACTION_MOVE:
                if (lassoActive) {
                    extendLasso(x, y);
                } else if (current != null) {
                    extendStroke(x, y, w);
                } else if (mode == MODE_ERASER) {
                    eraseAt(x, y, w);
                }
                break;

            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_POINTER_UP:
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (lassoActive) {
                    finishLasso();
                } else if (current != null) {
                    current.seal();
                    strokes.add(current);
                    current = null;
                    rebuildLayer();
                }
                break;

            default:
                break;
        }

        notifyState(mode);
        invalidate();
        return true;
    }

    private float widthFromPressure(float pressure, float size) {
        float base = penWidth;
        if (pressure > 0.01f && pressure <= 1f) {
            return base * (0.55f + 0.9f * pressure);
        }
        if (size > 0.001f) {
            return base * Math.min(2.2f, 0.6f + size * 3f);
        }
        return base;
    }

    private void beginStroke(float x, float y, float w) {
        current = new Stroke();
        current.color = penColor;
        current.alpha = 255;
        current.highlighter = false;
        current.start(x, y, w);
    }

    private void extendStroke(float x, float y, float w) {
        if (current == null) {
            beginStroke(x, y, w);
            return;
        }
        PointF last = current.pointAt(current.size() - 1);
        float dx = x - last.x, dy = y - last.y;
        if (dx * dx + dy * dy < 4f) {
            return;
        }
        current.extend(x, y, w);
    }

    /** 整笔橡皮：点中某条笔迹即删除该笔（与小猿"笔迹级删除"语义一致） */
    private void eraseAt(float x, float y, float w) {
        float r = Math.max(w, dp(12f));
        for (int i = strokes.size() - 1; i >= 0; i--) {
            Stroke s = strokes.get(i);
            if (!s.bounds.contains(x, y)) {
                continue;
            }
            if (s.hasPointNear(x, y, r)) {
                strokes.remove(i);
                rebuildLayer();
                return;
            }
        }
    }

    // ---------------- 圈选删除 ----------------

    private void beginLasso(float x, float y) {
        lassoActive = true;
        lassoPoints.clear();
        lassoHits.clear();
        lassoPath.reset();
        lassoPath.moveTo(x, y);
        lassoPoints.add(new PointF(x, y));
    }

    private void extendLasso(float x, float y) {
        PointF last = lassoPoints.get(lassoPoints.size() - 1);
        float dx = x - last.x, dy = y - last.y;
        float minDist = dp(3f);
        if (dx * dx + dy * dy < minDist * minDist) {
            return;
        }
        if (lassoPoints.size() < LASSO_SAMPLE) {
            lassoPoints.add(new PointF(x, y));
        } else {
            lassoPoints.set(lassoPoints.size() - 1, new PointF(x, y));
        }
        lassoPath.lineTo(x, y);
        updateLassoHits();
    }

    private void updateLassoHits() {
        lassoHits.clear();
        if (lassoPoints.size() < 3) {
            return;
        }
        computeLassoBounds();
        for (int i = 0, n = strokes.size(); i < n; i++) {
            Stroke s = strokes.get(i);
            if (isStrokeInsideLasso(s)) {
                lassoHits.add(s);
            }
        }
    }

    private void finishLasso() {
        lassoActive = false;
        if (lassoPoints.size() < 3) {
            lassoPoints.clear();
            lassoHits.clear();
            lassoPath.reset();
            return;
        }
        computeLassoBounds();
        float minSide = dp(MIN_LASSO_AREA_DP);
        if (lassoBox.width() < minSide && lassoBox.height() < minSide) {
            PointF c = lassoCentroid();
            eraseAt(c.x, c.y, dp(14f));
        } else {
            updateLassoHits();
            if (!lassoHits.isEmpty()) {
                strokes.removeAll(lassoHits);
                rebuildLayer();
            }
        }
        lassoPoints.clear();
        lassoHits.clear();
        lassoPath.reset();
    }

    private void computeLassoBounds() {
        lassoBox.setEmpty();
        if (lassoPoints.isEmpty()) {
            return;
        }
        PointF p0 = lassoPoints.get(0);
        lassoBox.set(p0.x, p0.y, p0.x, p0.y);
        for (int i = 1, n = lassoPoints.size(); i < n; i++) {
            PointF p = lassoPoints.get(i);
            if (p.x < lassoBox.left) lassoBox.left = p.x;
            if (p.y < lassoBox.top) lassoBox.top = p.y;
            if (p.x > lassoBox.right) lassoBox.right = p.x;
            if (p.y > lassoBox.bottom) lassoBox.bottom = p.y;
        }
    }

    private PointF lassoCentroid() {
        float sx = 0f, sy = 0f;
        for (int i = 0, n = lassoPoints.size(); i < n; i++) {
            PointF p = lassoPoints.get(i);
            sx += p.x;
            sy += p.y;
        }
        int n = Math.max(1, lassoPoints.size());
        return new PointF(sx / n, sy / n);
    }

    /**
     * 等价于 OpenCV pointPolygonTest 的包含判定：
     * 先做包围盒快速排除，再对笔迹采样点做射线法，落点比例达到阈值即认为被圈中。
     */
    private boolean isStrokeInsideLasso(Stroke s) {
        if (!RectF.intersects(lassoBox, s.bounds)) {
            return false;
        }
        List<PointF> pts = s.sample(48);
        int total = pts.size();
        if (total == 0) {
            return false;
        }
        int inside = 0;
        for (int i = 0; i < total; i++) {
            PointF p = pts.get(i);
            if (pointInPolygon(p.x, p.y, lassoPoints)) {
                inside++;
            }
        }
        if (inside == 0) {
            return false;
        }
        return inside / (float) total >= lassoRatio;
    }

    private static boolean pointInPolygon(float x, float y, List<PointF> poly) {
        boolean inside = false;
        int n = poly.size();
        for (int i = 0, j = n - 1; i < n; j = i++) {
            float xi = poly.get(i).x, yi = poly.get(i).y;
            float xj = poly.get(j).x, yj = poly.get(j).y;
            if ((yi > y) != (yj > y)) {
                float xIntersect = (xj - xi) * (y - yi) / (yj - yi) + xi;
                if (x < xIntersect) {
                    inside = !inside;
                }
            }
        }
        return inside;
    }

    // ===================== 绘制 =====================

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0 && h > 0) {
            if (layer != null) {
                layer.recycle();
            }
            layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            layerCanvas = new Canvas(layer);
            rebuildLayer();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (layer != null && !layer.isRecycled()) {
            layer.recycle();
        }
        layer = null;
        layerCanvas = null;
    }

    private void rebuildLayer() {
        if (layer == null || layer.isRecycled() || layerCanvas == null) {
            return;
        }
        layer.eraseColor(Color.TRANSPARENT);
        for (int i = 0, n = strokes.size(); i < n; i++) {
            drawStroke(layerCanvas, strokes.get(i));
        }
    }

    private void drawStroke(Canvas c, Stroke s) {
        strokePaint.setColor(s.color);
        strokePaint.setAlpha(s.highlighter ? 110 : s.alpha);
        strokePaint.setStrokeWidth(Math.max(1f, s.avgWidth()));
        c.drawPath(s.path, strokePaint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (layer != null && !layer.isRecycled()) {
            canvas.drawBitmap(layer, 0f, 0f, null);
        }
        if (current != null) {
            drawStroke(canvas, current);
        }
        if (lassoActive && lassoPoints.size() >= 2) {
            for (int i = 0, n = lassoHits.size(); i < n; i++) {
                Stroke s = lassoHits.get(i);
                hitPaint.setStrokeWidth(Math.max(dp(4f), s.avgWidth() + dp(4f)));
                canvas.drawPath(s.path, hitPaint);
            }
            lassoClosed.set(lassoPath);
            lassoClosed.close();
            canvas.drawPath(lassoClosed, lassoFillPaint);
            canvas.drawPath(lassoClosed, lassoPaint);
        }
        if (debugOverlay) {
            drawDebug(canvas);
        }
    }

    private void drawDebug(Canvas canvas) {
        float pad = dp(10f);
        float lineH = sp(17f);
        String[] lines = new String[]{
                "toolType=" + lastToolType + "  " + StylusUtil.toolName(lastToolType),
                "buttonState=" + StylusUtil.buttonName(lastButtonState),
                "mode=" + modeName(lastKeyDown ? keyAction : activeMode)
                        + (stylusOnly ? "  [仅笔可写]" : "  [手指可写]"),
                "笔迹=" + strokes.size() + "   圈中=" + lassoHits.size()
        };
        float w = dp(250f);
        float h = lineH * lines.length + dp(8f);
        canvas.drawRoundRect(pad, pad, pad + w, pad + h, dp(8f), dp(8f), debugBgPaint);
        float ty = pad + lineH;
        for (int i = 0; i < lines.length; i++) {
            canvas.drawText(lines[i], pad + dp(8f), ty, debugPaint);
            ty += lineH;
        }
    }

    private void notifyState(int mode) {
        lastReportedMode = mode;
        if (stateListener != null) {
            stateListener.onStylusState(lastToolType, lastButtonState, mode, strokes.size());
        }
    }

    // ===================== 对外 API =====================

    public void undo() {
        if (strokes.isEmpty()) {
            return;
        }
        undoStack.add(strokes.remove(strokes.size() - 1));
        rebuildLayer();
        invalidate();
    }

    public void redo() {
        if (undoStack.isEmpty()) {
            return;
        }
        strokes.add(undoStack.remove(undoStack.size() - 1));
        rebuildLayer();
        invalidate();
    }

    public boolean canUndo() {
        return !strokes.isEmpty();
    }

    public boolean canRedo() {
        return !undoStack.isEmpty();
    }

    public void clearAll() {
        strokes.clear();
        undoStack.clear();
        current = null;
        lassoActive = false;
        lassoPoints.clear();
        lassoHits.clear();
        lassoPath.reset();
        rebuildLayer();
        invalidate();
    }

    public int strokeCount() {
        return strokes.size();
    }

    public void exportTo(Canvas canvas) {
        canvas.drawColor(Color.WHITE);
        if (layer != null && !layer.isRecycled()) {
            canvas.drawBitmap(layer, 0f, 0f, null);
        }
    }

    public void setPenColor(int color) {
        this.penColor = color;
        this.activeMode = MODE_PEN;
        invalidate();
    }

    public int getPenColor() {
        return penColor;
    }

    public void setPenWidth(float widthPx) {
        this.penWidth = Math.max(1f, widthPx);
    }

    public float getPenWidth() {
        return penWidth;
    }

    public void setActiveMode(int mode) {
        this.activeMode = mode;
        this.current = null;
        invalidate();
    }

    public int getActiveMode() {
        return activeMode;
    }

    public void setStylusOnly(boolean stylusOnly) {
        this.stylusOnly = stylusOnly;
    }

    public boolean isStylusOnly() {
        return stylusOnly;
    }

    public void setKeyButton(int buttonMask) {
        this.keyButton = buttonMask;
    }

    public int getKeyButton() {
        return keyButton;
    }

    public void setKeyAction(int action) {
        this.keyAction = action;
    }

    public int getKeyAction() {
        return keyAction;
    }

    public void setDebugOverlay(boolean debugOverlay) {
        this.debugOverlay = debugOverlay;
        invalidate();
    }

    public boolean isDebugOverlay() {
        return debugOverlay;
    }

    public void setLassoRatio(float ratio) {
        this.lassoRatio = Math.min(1f, Math.max(0.05f, ratio));
    }

    public float getLassoRatio() {
        return lassoRatio;
    }

    public void setOnStylusStateListener(OnStylusStateListener l) {
        this.stateListener = l;
    }

    public void applyPrefs(Prefs p) {
        setStylusOnly(p.isStylusOnly());
        setKeyAction(p.getKeyAction());
        setKeyButton(p.getKeyButton());
        setDebugOverlay(p.isDebugOverlay());
        setPenWidth(p.getPenWidth());
        setLassoRatio(p.getLassoRatio());
        invalidate();
    }
}
