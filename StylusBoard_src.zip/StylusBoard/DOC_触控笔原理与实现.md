# 触控笔调用逻辑还原与画板应用实现原理

> 目标：从小猿AI学习机系统应用（`com.megrez.app.x1.business` v1.18.2）还原触控笔的识别与"按键圈选删除"逻辑，并生成一个可独立安装、可自定义按键行为的示例画板应用 `StylusBoard`（包名 `com.example.stylusboard`）。

---

## 一、逆向工程过程

### 1.1 输入与工具
- 输入：7 个 7z 分卷（`小猿AI学习机_1.18.2.7z.001~007`），合并解压得到 `小猿AI学习机_1.18.2.apk`（264 MB）。
- 工具受限：环境内 GitHub 直连失败，jadx / apktool 不可用。
- 替代方案：使用 Android SDK build-tools 34.0.0 自带工具，功能等价：
  - `aapt dump badging`：读取包名、版本、SDK、启动组件。
  - `unzip`：抽取 5 个 dex。
  - `dexdump -d`：将每个 dex 反汇编为 Dalvik 指令文本（共约 486 MB）。
  - `strings` + `grep`：在反汇编文本中检索关键词。

### 1.2 检索路径
```bash
# 定位触控笔相关类
grep -rlE "Stylus|stylus|getToolType|getButtonState" dex_*.txt
# 定位按键判定方法
grep -nE "getButtonState|0x20|BUTTON_STYLUS" dex_classes4_full.txt
# 定位圈选/多边形删除
grep -nE "pointPolygonTest|convexHull|findContours" dex_*.txt
```

### 1.3 APK 基本信息
| 项 | 值 |
|---|---|
| 包名 | `com.megrez.app.x1.business` |
| versionName | 1.18.2 |
| minSdk | 29 |
| targetSdk | 33 |
| 关键 so | `libopencv_java4.so`（圈选判定）、`libengine_jni.so`、`libdigitalink.so`（实为 ML Kit 手写识别，与笔按键无关） |

---

## 二、核心发现：触控笔三层调用链

### 第 1 层 · 识别层（按键 → 工具类型改写）
类：`com.megrez.x1.view.util.e`（位于 classes4.dex）
方法：`public static final int a(MotionEvent)`

```java
public static final int a(MotionEvent event) {
    if (event.getButtonState() == 32) {   // 0x20 = BUTTON_STYLUS_PRIMARY
        return 4;                          // 借用未占用值 4 表示"笔键态"
    }
    return event.getToolType(0);           // 否则返回系统真实工具类型
}
```

**语义**：
- `getButtonState()==32` 表示笔身主按键被按下。
- 此时把"有效工具类型"强制改写为 `4`。
- `4` 在 Android 8 及以前是 `TOOL_TYPE_BRUSH`，Android 13(API 33) 起系统定义为 `TOOL_TYPE_ERASER`。小猿借用该值统一表示"笔键按下 → 橡皮/圈选态"。

### 第 2 层 · 分发/过滤层（只放行笔事件）
类：`com.fenbi.megrez.app.megrezView.StylusLayout`（classes.dex，extends FrameLayout）
方法：`onFilterTouchEventForSecurity(MotionEvent)`

```java
public boolean onFilterTouchEventForSecurity(MotionEvent event) {
    int t = com.megrez.x1.view.util.e.a(event);   // 调用第1层
    return super.onFilterTouchEventForSecurity(event)
            && (t == 2 || t == 4);                // 2=STYLUS, 4=笔键态
}
```

**语义**：仅当有效工具类型为 `2`(触控笔) 或 `4`(笔键态) 时事件才向子 View 分发；手指(`1`)、鼠标(`3`) 被丢弃。这是"仅笔可写"的实现点。

### 第 3 层 · 圈选删除层（闭合圈 → 删除圈内笔迹）
- 按住笔身键 → 第1层返回 4 → 第2层放行 → 画板进入"圈选/橡皮"态。
- 抬手时形成一条闭合轨迹（多边形）。
- 对每条已有笔迹，用 **OpenCV** 判定是否落在圈内：
  - `findContours` / `convexHull`：把圈轨迹构造成多边形轮廓。
  - `pointPolygonTest`：逐点判定笔迹采样点是否在多边形内（返回 >0 为内部）。
- 命中阈值后删除该笔迹。

**完整链路**：
```
按住笔身键(buttonState==32)
   → e.a() 改写有效工具类型为 4
   → StylusLayout 放行该事件
   → 画板进入圈选态，记录闭合圈点
   → 抬手：pointPolygonTest 判定圈内笔迹
   → 删除圈内笔迹
```

---

## 三、示例应用 StylusBoard 的复刻与增强

工程：`/home/admin/workspace/StylusBoard`，7 个类，纯 Java + Android framework（无第三方库、无 androidx）。

### 3.1 逐字节复刻映射表
| 小猿原始实现 | StylusBoard 对应 | 说明 |
|---|---|---|
| `com.megrez.x1.view.util.e.a(MotionEvent)` | `StylusUtil.effectiveToolType(MotionEvent)` | 严格 `buttonState==32 → 4`，否则 `getToolType(0)` |
| `StylusLayout.onFilterTouchEventForSecurity` | `StylusBoardView.onFilterTouchEventForSecurity` | 仅放行 toolType 2/4（可在设置开关） |
| OpenCV `pointPolygonTest` | `StylusBoardView.pointInPolygon`（射线法） | 数学等价的点在多边形内判定 |
| `convexHull` 构造轮廓 | 直接以圈轨迹点集为多边形 | 画板场景点已有序，无需凸包 |
| 笔迹模型 | `Stroke`（点列表+逐点宽度+Path+包围盒） | 二次贝塞尔中点平滑 |

### 3.2 类清单
| 类 | 职责 |
|---|---|
| `StylusUtil` | 复刻第1层按键判定；提供 `isKeyDown`/`toolName`/`buttonName` |
| `Stroke` | 单条笔迹数据模型与几何采样 |
| `StylusBoardView` | 画板核心：第2层事件过滤 + 绘制 + 第3层圈选删除 + 橡皮 + 撤销 |
| `Prefs` | SharedPreferences 封装按键自定义配置 |
| `MainActivity` | 画板容器 + 工具栏（画笔/橡皮/圈选/颜色/撤销/重做/清空/保存/设置） |
| `SettingsActivity` | 按键行为、监听键、圈选阈值、笔粗细、调试开关 |
| `R` | aapt2 生成的资源引用 |

### 3.3 圈选删除算法（等价实现）
```java
// 1) 包围盒快速排除
if (!RectF.intersects(lassoBox, stroke.bounds)) return false;
// 2) 对笔迹等间隔降采样(≤48点)
List<PointF> pts = stroke.sample(48);
// 3) 射线法逐点判定，统计落在圈内的比例
int inside = 0;
for (PointF p : pts) if (pointInPolygon(p.x, p.y, lassoPoints)) inside++;
// 4) 比例达到阈值(默认0.5)即认为"被圈中"
return inside / (float) pts.size() >= lassoRatio;
```
- `pointInPolygon` 为经典射线法（crossing number），与 `pointPolygonTest>0` 等价。
- 极小圈（宽高均 < 48dp）退化为"点选删除"，提升误操作容错。

### 3.4 按键自定义（增强，原系统写死）
小猿把"笔身键 → 圈选/橡皮"硬编码在 `e.a()`。StylusBoard 通过 `Prefs` 开放为可配置：
- **按键行为**：圈选删除 / 橡皮擦 / 画笔 / 撤销。
- **监听键**：主键 `0x20`（默认，与小猿一致）/ 副键 `0x40` / 任意 `0x60`。
- **仅笔可写**：开关第2层过滤（复刻 StylusLayout）。
- **圈选阈值 / 笔粗细 / 调试信息**：可调。

### 3.5 真机验证辅助
画板左上角实时显示：
```
toolType=2  STYLUS(触控笔)
buttonState=0x20 笔身主键(0x20)
mode=圈选删除  [手指可写]
笔迹=3   圈中=1
```
若某支笔的按键值不是 0x20，可在设置里改监听键，无需改代码。

---

## 四、手工构建管线与排障记录

环境：Android SDK `/opt/android-sdk`，build-tools 34.0.0，platform android-34，多 JDK（8/11/17/21）。**不使用 Gradle**（规避联网拉依赖）。

### 4.1 管线（见 `build.sh`）
```
aapt2 compile → aapt2 link(生成R.java+基础APK) → javac → d8 → dex入包 → zipalign → apksigner
```

### 4.2 三个关键坑（均已解决）
1. **aapt2 link 资源传入方式**
   - 错误：`-R gen/res.zip`（`-R` 是 overlay，要求资源已存在于基础包）→ 报 `does not override an existing resource`。
   - 正确：把 `gen/res.zip` 作为**位置参数**直接传给 `aapt2 link`。

2. **vector drawable 属性**
   - 错误：`android:strokeDashArray` 不被 `<path>` 支持 → 链接失败 `attribute ... not found`。
   - 正确：删除该属性，虚线效果改由代码 `DashPathEffect` 实现。

3. **JDK 21 javac 与 R8 8.2.2-dev 不兼容**
   - 现象：d8 抛 `NullPointerException: Cannot invoke "String.length()" because "<parameter1>" is null`，定位到匿名内部类 `MainActivity$5.class`。
   - 诊断：该 class major version=52、无 NestHost/NestMembers，仅有 EnclosingMethod 与 `access$000`；android.jar 同为 52。换 JDK 17 运行 d8 仍失败 → 根因在**输入 class**，即 JDK 21 的 javac 即便加 `-source/-target 8` 仍写入新版元数据，老 R8 无法解析。
   - 正确：**改用 JDK 8 的 javac**（`/usr/lib/jvm/java-8-openjdk-amd64/bin/javac`）重编，d8 立即成功。

### 4.3 产物校验
```
package: name='com.example.stylusboard' versionCode='1' versionName='1.0'
sdkVersion:'21'  targetSdkVersion:'33'
launchable-activity: name='com.example.stylusboard.MainActivity'
apksigner verify: v1=true v2=true v3=true
zipalign -c: ALIGN_OK
dex 关键类: MainActivity, Prefs, R, SettingsActivity, Stroke, StylusBoardView, StylusUtil
```

---

## 五、已知修复：画板高度塌缩
- 现象：安装后"画板尚未就绪，无法书写"。
- 根因：`MainActivity` 曾把画板放进 `ScrollView`，而画板用 `weight=1` 占剩余空间。`ScrollView` 以 `UNSPECIFIED` 测量子 View 高度，导致 `weight` 失效 → 画板高度塌缩为 0 → 触摸区域消失，`getWidth()/getHeight()` 返回 0。
- 修复：移除 `ScrollView`，直接 `setContentView(root)`。

---

## 六、安装与使用
```bash
adb install StylusBoard.apk        # 或点击 APK 安装
```
1. 打开即可用手指或触控笔书写（默认手指可画）。
2. 进"设置" → 开启"仅触控笔可书写" → 完全复刻小猿 StylusLayout 过滤。
3. 按住笔身键（默认 0x20）画一个闭合圈 → 圈内笔迹被删除。
4. 若按键不触发：看左上角 `buttonState` 实际值，在设置里把监听键改为 0x40 / 0x60。
5. "保存PNG" 将当前画板导出到应用私有 Pictures 目录。

---

## 七、免责声明
本项目仅用于**学习与兼容性适配研究**，复刻的是公开的输入事件处理逻辑，不含任何系统应用的受版权保护代码或资源。示例应用为独立实现，与小猿AI学习机无隶属关系。
