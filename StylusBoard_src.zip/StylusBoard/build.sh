#!/usr/bin/env bash
# StylusBoard 手工构建脚本（不依赖 Gradle）
# 关键：必须用 JDK 8 的 javac 编译，否则 JDK21 javac 生成的 class 元数据
#       会导致 build-tools 34.0.0 的 R8 8.2.2-dev d8 抛 NullPointerException。
set -e

# ==== 可配置路径 ====
SDK=/opt/android-sdk
BT=$SDK/build-tools/34.0.0
PLATFORM=$SDK/platforms/android-34/android.jar
JDK8=/usr/lib/jvm/java-8-openjdk-amd64
PROJECT="$(cd "$(dirname "$0")" && pwd)"
KS_PASS=stylus123
KS_ALIAS=stylus

export PATH=$BT:$PATH
cd "$PROJECT"

echo "[1/7] aapt2 compile"
rm -f gen/res.zip
mkdir -p gen obj apk
aapt2 compile --dir res -o gen/res.zip

echo "[2/7] aapt2 link  (注意：res.zip 作为位置参数，不能用 -R overlay)"
rm -f apk/unaligned.apk
rm -rf gen/com
aapt2 link -o apk/unaligned.apk \
  -I "$PLATFORM" \
  --manifest AndroidManifest.xml \
  gen/res.zip \
  --java gen/ \
  --min-sdk-version 21 --target-sdk-version 33 \
  --version-code 1 --version-name 1.0

echo "[3/7] javac (JDK8)"
rm -rf obj
mkdir -p obj
"$JDK8/bin/javac" -encoding UTF-8 \
  -bootclasspath "$PLATFORM" \
  -classpath gen \
  -d obj \
  $(find src gen -name '*.java')

echo "[4/7] d8 -> classes.dex"
d8 --lib "$PLATFORM" --min-api 21 --output obj \
  $(find obj -name '*.class')

echo "[5/7] 把 classes.dex 塞进 APK"
cp apk/unaligned.apk apk/tmp.apk
( cd obj && zip -q -j ../apk/tmp.apk classes.dex )

echo "[6/7] zipalign"
zipalign -p -f 4 apk/tmp.apk apk/aligned.apk

echo "[7/7] 签名（首次自动生成 keystore）"
[ -f release.keystore ] || "$JDK8/bin/keytool" -genkeypair \
  -keystore release.keystore -alias "$KS_ALIAS" \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$KS_PASS" -keypass "$KS_PASS" \
  -dname "CN=StylusBoard, OU=Example, O=Example, L=BJ, C=CN"
apksigner sign --ks release.keystore \
  --ks-pass pass:"$KS_PASS" --key-pass pass:"$KS_PASS" \
  --out apk/StylusBoard.apk apk/aligned.apk

echo "==== 验证 ===="
apksigner verify --verbose apk/StylusBoard.apk | grep -E 'Verifies|v1 scheme|v2 scheme|v3 scheme'
aapt dump badging apk/StylusBoard.apk | grep -E "package:|launchable-activity|targetSdkVersion"
zipalign -c -v 4 apk/StylusBoard.apk >/dev/null && echo "ALIGN_OK"
ls -la apk/StylusBoard.apk
echo "DONE -> apk/StylusBoard.apk"
